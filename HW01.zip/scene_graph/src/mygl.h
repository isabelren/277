#ifndef MYGL_H
#define MYGL_H

#include <glwidget277.h>
#include <utils.h>
#include <shaderprogram.h>
#include <scene/cylinder.h>
#include <scene/sphere.h>
#include <scene/cube.h>
#include <scene/node.h>

#include <QOpenGLVertexArrayObject>
#include <QOpenGLShaderProgram>


class MyGL
    : public GLWidget277
{
private:
    QOpenGLVertexArrayObject vao;

    Cylinder geom_cylinder;//The instance of a unit cylinder we can use to render any cylinder
    Sphere geom_sphere;//The instance of a unit sphere we can use to render any sphere
    Cube geom_cube; //unit cube
    ShaderProgram prog_lambert;
    ShaderProgram prog_wire;
    Node* root;

public:
    explicit MyGL(QWidget *parent = 0);
    ~MyGL();

    void initializeGL();
    void resizeGL(int w, int h);
    Node* createNode(float tx, float ty, float tz, float rx, float ry, float rz, float sx, float sy, float sz, const glm::vec4& c, ShaderProgram::Drawable* g);
    void traverse(Node* N, glm::mat4 t);
    void drawShape(ShaderProgram::Drawable* shape, glm::vec4 color, glm::mat4 transformation);
    void paintGL();

protected:
    void keyPressEvent(QKeyEvent *e);
};


#endif // MYGL_H
